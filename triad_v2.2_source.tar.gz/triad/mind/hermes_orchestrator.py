"""
hermes_orchestrator.py — Hermes 主大脑编排循环 (Orchestrator)

Triad 第二层核心编排器，串联 5 个独立模块：
  1. ModelRouter      — 动态 LLM 路由
  2. NovelCurator    — 4维小说评估 + 技能固化
  3. StreamingReporter — 非阻塞状态上报到 OpenClaw
  4. VRAMScheduler   — 显存跷跷板 (GPU ↔ CPU_FALLBACK)
  5. ComfyUIMCPBridge — 概念图生成 (ComfyUI)

设计原则：
  - 每一步都是 try/except 容错，失败不阻断主流程
  - reporter 全程非阻塞埋点，用户实时可见进度
  - 支持 async for 批量任务流式处理
  - 完全类型注解
"""

from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from typing import (
    Any,
    AsyncIterator,
    Dict,
    List,
    Optional,
    Protocol,
    runtime_checkable,
)

# ---------------------------------------------------------------------------
# 日志配置
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("HermesOrchestrator")

# ---------------------------------------------------------------------------
# Stub 类型定义（当真实模块未就绪时回退使用）
# ---------------------------------------------------------------------------

@dataclass
class RouteDecision:
    """模型路由决策结果"""
    vendor: str = "openai"
    model: str = "gpt-4o"
    temperature: float = 0.7
    base_url: str = ""
    api_key: str = ""


@dataclass
class LLMResponse:
    """LLM 返回的原始响应"""
    content: str = ""
    usage: Dict[str, int] = field(default_factory=dict)


@dataclass
class AssessmentReport:
    """小说评估报告"""
    overall: float = 0.0
    character_consistency: float = 0.0
    plot_logic: float = 0.0
    style_coherence: float = 0.0
    emotional_impact: float = 0.0


@dataclass
class SkillEntry:
    """固化后的技能条目"""
    name: str = ""
    pattern: str = ""
    score: float = 0.0


@dataclass
class ToolResult:
    """工具调用结果"""
    success: bool = False
    output: str = ""
    error: str = ""


# ---------------------------------------------------------------------------
# 依赖模块的优雅导入（stub fallback）
# ---------------------------------------------------------------------------

# --- ModelRouter ---
try:
    from mind.model_router import ModelRouter as _ModelRouter
except Exception:
    class _ModelRouter:
        """ModelRouter stub — 真实环境由 model_router.py 提供"""
        async def route(self, task: str, strategy: Optional[str] = None) -> RouteDecision:
            logger.warning("[STUB] ModelRouter.route() 使用默认决策")
            return RouteDecision(vendor="stub", model="stub-model")

        async def execute(self, task: str, decision: RouteDecision) -> LLMResponse:
            logger.warning("[STUB] ModelRouter.execute() 返回占位响应")
            await asyncio.sleep(0.05)  # 模拟网络延迟
            return LLMResponse(
                content=f"[STUB-RESPONSE] 任务: {task[:60]}...",
                usage={"prompt_tokens": 10, "completion_tokens": 20},
            )


# --- NovelCurator ---
try:
    from mind.novel_curator import NovelCurator as _NovelCurator
except Exception:
    class SkillCrystallizer:
        """技能固化器 stub"""
        def crystallize_skill(
            self, prompt: str, generated: str, report: AssessmentReport
        ) -> SkillEntry:
            return SkillEntry(
                name=f"skill_{hash(prompt) % 10000:04d}",
                pattern=prompt[:40],
                score=report.overall,
            )

    class _NovelCurator:
        """NovelCurator stub"""
        def __init__(self, router: Any = None):
            self.crystallizer = SkillCrystallizer()

        async def evaluate(
            self, chapter_text: str, characters: List[str], use_llm: bool = True
        ) -> AssessmentReport:
            logger.warning("[STUB] NovelCurator.evaluate() 返回默认评估")
            await asyncio.sleep(0.05)
            return AssessmentReport(
                overall=8.0,
                character_consistency=8.5,
                plot_logic=7.5,
                style_coherence=8.0,
                emotional_impact=7.0,
            )


# --- StreamingReporter ---
try:
    from mind.acp_adapter.streaming_reporter import StreamingReporter as _StreamingReporter
except Exception:
    class _StreamingReporter:
        """StreamingReporter stub — 后台 HTTP POST 到 OpenClaw Gateway"""
        async def report_stage(
            self,
            task_id: str,
            stage: str,
            message: str,
            progress: Optional[float] = None,
        ) -> bool:
            logger.info(f"[REPORT][{task_id}] stage={stage} progress={progress} | {message}")
            return True

        async def report_result(self, task_id: str, status: str, output: str) -> bool:
            logger.info(f"[REPORT][{task_id}] status={status} | output={output[:80]}...")
            return True

        async def report_model_info(
            self,
            task_id: str,
            vendor: str,
            model: str,
            prompt_tokens: int,
            completion_tokens: int,
        ) -> bool:
            logger.info(
                f"[REPORT][{task_id}] model={vendor}/{model} "
                f"tokens={prompt_tokens}+{completion_tokens}"
            )
            return True

        async def report_vram(
            self,
            task_id: str,
            state: str,
            embedding_mb: int,
            llm_mb: int,
            comfyui_mb: int,
            free_mb: int,
        ) -> bool:
            logger.info(
                f"[REPORT][{task_id}] VRAM state={state} "
                f"emb={embedding_mb}MB llm={llm_mb}MB comfy={comfyui_mb}MB free={free_mb}MB"
            )
            return True


# --- VRAMScheduler ---
try:
    from hand.vram_scheduler_llama import VRAMScheduler as _VRAMScheduler
except Exception:
    @dataclass
    class RenderContext:
        """显存渲染上下文 stub"""
        clawpod_id: str = ""
        mode: str = "CPU_FALLBACK"

    class _VRAMScheduler:
        """VRAMScheduler stub — GPU ↔ CPU_FALLBACK 跷跷板"""
        @asynccontextmanager
        async def acquire_render_memory(self, clawpod_id: str):
            logger.warning(f"[STUB] VRAM: {clawpod_id} 切换到 CPU_FALLBACK")
            ctx = RenderContext(clawpod_id=clawpod_id, mode="CPU_FALLBACK")
            try:
                yield ctx
            finally:
                logger.warning(f"[STUB] VRAM: {clawpod_id} 渲染上下文释放")

        async def release_render_memory(self, clawpod_id: str) -> bool:
            logger.warning(f"[STUB] VRAM: {clawpod_id} 恢复 GPU 模式")
            return True


# --- ComfyUIMCPBridge ---
try:
    from hand.comfyui_mcp_bridge import ComfyUIMCPBridge as _ComfyUIMCPBridge
except Exception:
    class _ComfyUIMCPBridge:
        """ComfyUIMCPBridge stub — 概念图生成"""
        async def generate_character_concept(
            self,
            character_description: str,
            style_preset: str = "anime",
            **kwargs: Any,
        ) -> ToolResult:
            logger.warning("[STUB] ComfyUIMCPBridge.generate_character_concept() 返回占位图")
            await asyncio.sleep(0.1)
            return ToolResult(
                success=True,
                output="/tmp/stub_concept_art.png",
                error="",
            )


# ---------------------------------------------------------------------------
# 核心类：HermesOrchestrator
# ---------------------------------------------------------------------------

class HermesOrchestrator:
    """
    Hermes 主大脑编排循环。

    串联 5 个模块，按 5 步流水线处理任务：
      1. ANALYZING  — 任务类型分析
      2. ROUTING    — 模型路由决策
      3. EXECUTION  — LLM 内容生成
      4. EVALUATION — 小说质量评估（可选）
      5. MULTIMODAL — ComfyUI 概念图生成（可选）

    容错设计：
      - 第 3 步失败 → 任务整体失败，上报 failed
      - 第 4/5 步失败 → 仅记录 warning，不阻断成功返回
      - reporter 全程非阻塞，任何上报异常都被吞掉
    """

    def __init__(
        self,
        router: Optional[_ModelRouter] = None,
        curator: Optional[_NovelCurator] = None,
        reporter: Optional[_StreamingReporter] = None,
        vram_scheduler: Optional[_VRAMScheduler] = None,
        comfy_bridge: Optional[_ComfyUIMCPBridge] = None,
    ) -> None:
        self.router = router or _ModelRouter()
        self.curator = curator or _NovelCurator(router=self.router)
        self.reporter = reporter or _StreamingReporter()
        self.vram_scheduler = vram_scheduler or _VRAMScheduler()
        self.comfy_bridge = comfy_bridge or _ComfyUIMCPBridge()
        logger.info("HermesOrchestrator 初始化完成")

    # ------------------------------------------------------------------
    # 公开 API：单任务处理
    # ------------------------------------------------------------------

    async def process_task(self, task_request: Dict[str, Any]) -> Dict[str, Any]:
        """
        处理单个任务请求，执行完整 5 步流水线。

        Args:
            task_request: 必须包含 "taskId" 和 "raw_input"；
                          可选 "strategy" (默认 "AUTO")

        Returns:
            {"taskId": ..., "status": "success"|"failed", "output": ..., ...}
        """
        # --- 提取字段 --------------------------------------------------
        try:
            task_id = task_request["taskId"]
        except KeyError:
            logger.error("task_request 缺少必需字段 'taskId'")
            return {"status": "failed", "error": "missing taskId"}

        user_prompt = task_request.get("raw_input", "")
        strategy = task_request.get("strategy", "AUTO")

        logger.info(f"[{task_id}] ===== 开始处理任务 =====")
        logger.info(f"[{task_id}] prompt={user_prompt[:80]}... strategy={strategy}")

        # --- Step 1: ANALYZING -----------------------------------------
        await self._safe_report_stage(task_id, "ANALYZING", "Hermes 正在分析任务类型...", 0.1)
        task_type = self._classify_task(user_prompt)
        logger.info(f"[{task_id}] 任务类型判定: {task_type}")

        # --- Step 1.5: 角色解析 ----------------------------------------
        role = None
        clean_input = user_prompt
        try:
            if hasattr(self.router, "parse_role"):
                role, clean_input = self.router.parse_role(user_prompt)
        except Exception as exc:
            # 未知角色时记录警告但不阻断，回退到默认逻辑
            logger.warning(f"[{task_id}] 角色解析失败 (非致命): {exc}")

        if role:
            await self._safe_report_stage(
                task_id, "ANALYZING", f"🎭 角色模式: {role.name} ({role.id})", 0.15
            )
            effective_strategy = role.model_pref
            task_type = self._classify_task(clean_input)
            logger.info(
                f"[{task_id}] 启用角色: {role.name} | 策略={role.model_pref} | "
                f"工具={role.allowed_tools} | 温度={role.temperature}"
            )
        else:
            effective_strategy = strategy

        # --- Step 2: ROUTING -------------------------------------------
        await self._safe_report_stage(
            task_id, "ANALYZING", f"任务类型: {task_type}，正在路由模型...", 0.2
        )
        try:
            decision = await self._route_decision(clean_input, effective_strategy)
        except Exception as exc:
            logger.error(f"[{task_id}] 模型路由失败: {exc}")
            await self._safe_report_result(task_id, "failed", f"模型路由失败: {exc}")
            return {"taskId": task_id, "status": "failed", "error": f"routing_failed: {exc}"}

        await self._safe_report_model_info(task_id, decision.vendor, decision.model, 0, 0)

        # --- Step 3: EXECUTION -----------------------------------------
        await self._safe_report_stage(
            task_id, "READING_CODE", f"调用 {decision.vendor}/{decision.model} 生成内容...", 0.3
        )
        generated_text = ""
        try:
            # 如果存在角色，注入 system prompt 并限制工具权限
            if role and hasattr(self.router, "_inject_system_prompt"):
                prompt_for_llm = self.router._inject_system_prompt(clean_input, role.system_prompt)
                # 使用角色感知的执行层，记录工具权限到决策元数据
                if hasattr(self.router, "_execute_with_tools"):
                    llm_response = await self.router._execute_with_tools(
                        prompt_for_llm, decision, allowed_tools=role.allowed_tools
                    )
                else:
                    llm_response = await self._execute_decision(prompt_for_llm, decision)
            else:
                llm_response = await self._execute_decision(clean_input, decision)

            generated_text = llm_response.content
            await self._safe_report_model_info(
                task_id,
                decision.vendor,
                decision.model,
                llm_response.usage.get("prompt_tokens", 0),
                llm_response.usage.get("completion_tokens", 0),
            )
            logger.info(f"[{task_id}] LLM 生成完成，长度={len(generated_text)}")
        except Exception as exc:
            logger.error(f"[{task_id}] 模型调用失败: {exc}")
            await self._safe_report_result(task_id, "failed", f"模型调用失败: {exc}")
            return {"taskId": task_id, "status": "failed", "error": str(exc)}

        # --- Step 4: EVALUATION (仅小说类型) ----------------------------
        if task_type == "novel":
            await self._safe_report_stage(
                task_id, "TESTING", "正在评估小说质量...", 0.6
            )
            try:
                report = await self.curator.evaluate(
                    generated_text, characters=[], use_llm=True
                )
                critique = (
                    f"评估结果: 人设 {report.character_consistency}/10, "
                    f"逻辑 {report.plot_logic}/10, "
                    f"文风 {report.style_coherence}/10, "
                    f"情感 {report.emotional_impact}/10, "
                    f"综合 {report.overall}/10"
                )
                await self._safe_report_stage(task_id, "TESTING", critique, 0.7)
                logger.info(f"[{task_id}] {critique}")

                # 质量高 → 触发 SkillCrystallizer
                if report.overall >= 7.5:
                    try:
                        skill = self.curator.crystallizer.crystallize_skill(
                            user_prompt, generated_text, report
                        )
                        await self._safe_report_stage(
                            task_id,
                            "COMPLETED",
                            f"✨ 新技能已固化: {skill.name} (评分 {skill.score:.1f})",
                            0.8,
                        )
                        logger.info(f"[{task_id}] 技能固化: {skill.name}")
                    except Exception as sk_exc:
                        logger.warning(f"[{task_id}] 技能固化失败 (非致命): {sk_exc}")
            except Exception as exc:
                logger.warning(f"[{task_id}] 评估失败 (非致命): {exc}")

        # --- Step 5: MULTIMODAL (如果需要概念图) ------------------------
        needs_image = task_type == "multimodal" or self._needs_image(user_prompt)
        if needs_image:
            await self._safe_report_stage(
                task_id, "EDITING", "正在调度 ComfyUI 生成概念图...", 0.75
            )
            try:
                # VRAM 切换: GPU → CPU_FALLBACK (通过 async context manager)
                async with self.vram_scheduler.acquire_render_memory(task_id) as ctx:
                    await self._safe_report_vram(
                        task_id,
                        "RENDERING",
                        embedding_mb=2048,
                        llm_mb=0,
                        comfyui_mb=20480,
                        free_mb=0,
                    )
                    logger.info(f"[{task_id}] VRAM 进入渲染模式: {ctx.mode}")

                    # 调用 ComfyUI
                    result = await self.comfy_bridge.generate_character_concept(
                        character_description=generated_text[:500],
                        style_preset="anime",
                    )

                    if result.success:
                        image_path = result.output
                        await self._safe_report_stage(
                            task_id,
                            "COMPLETED",
                            f"🎨 概念图已生成: {image_path}",
                            0.9,
                        )
                        logger.info(f"[{task_id}] 概念图生成成功: {image_path}")
                    else:
                        await self._safe_report_stage(
                            task_id,
                            "FAILED",
                            f"概念图生成失败: {result.error}",
                            0.9,
                        )
                        logger.warning(f"[{task_id}] 概念图生成失败: {result.error}")

                # VRAM 恢复: CPU_FALLBACK → GPU
                await self._safe_report_vram(
                    task_id,
                    "IDLE",
                    embedding_mb=2048,
                    llm_mb=9216,
                    comfyui_mb=0,
                    free_mb=9216,
                )
                logger.info(f"[{task_id}] VRAM 恢复空闲模式")
            except Exception as exc:
                logger.error(f"[{task_id}] 多模态生成失败: {exc}")

        # --- 最终结果 --------------------------------------------------
        await self._safe_report_result(task_id, "success", generated_text)
        logger.info(f"[{task_id}] ===== 任务完成 =====")

        return {
            "taskId": task_id,
            "status": "success",
            "output": generated_text,
            "model_used": f"{decision.vendor}/{decision.model}",
            "task_type": task_type,
        }

    # ------------------------------------------------------------------
    # 公开 API：批量任务流式处理
    # ------------------------------------------------------------------

    async def process_tasks_stream(
        self, task_requests: List[Dict[str, Any]], max_concurrency: int = 3
    ) -> AsyncIterator[Dict[str, Any]]:
        """
        批量处理任务，返回异步生成器，支持流式消费结果。

        Args:
            task_requests: 任务请求列表
            max_concurrency: 最大并发数（默认 3，避免同时占用过多资源）

        Yields:
            每个任务完成后的结果 dict
        """
        semaphore = asyncio.Semaphore(max_concurrency)
        logger.info(f"批量任务开始: {len(task_requests)} 个任务, 并发限制={max_concurrency}")

        async def _bounded_process(req: Dict[str, Any]) -> Dict[str, Any]:
            async with semaphore:
                return await self.process_task(req)

        # 使用 as_completed 保证结果按完成顺序 yield，实现真正的流式
        pending = [asyncio.create_task(_bounded_process(req)) for req in task_requests]
        for coro in asyncio.as_completed(pending):
            try:
                result = await coro
                yield result
            except Exception as exc:
                logger.error(f"批量任务中某个协程异常: {exc}")
                yield {"status": "failed", "error": f"batch_exception: {exc}"}

    async def process_tasks(
        self, task_requests: List[Dict[str, Any]], max_concurrency: int = 3
    ) -> List[Dict[str, Any]]:
        """
        批量处理任务，返回完整结果列表（按完成顺序）。

        Args:
            task_requests: 任务请求列表
            max_concurrency: 最大并发数

        Returns:
            结果 dict 列表
        """
        results: List[Dict[str, Any]] = []
        async for result in self.process_tasks_stream(task_requests, max_concurrency):
            results.append(result)
        return results

    # ------------------------------------------------------------------
    # 辅助方法
    # ------------------------------------------------------------------

    def _classify_task(self, prompt: str) -> str:
        """
        基于关键词判断任务类型。

        Returns:
            'multimodal' | 'novel' | 'code' | 'chat'
        """
        prompt_lower = prompt.lower()
        multimodal_kw = [
            "设计角色", "概念图", "生成图片", "画图",
            "character concept", "生成图像", "画一张",
        ]
        if any(kw in prompt_lower for kw in multimodal_kw):
            return "multimodal"

        novel_kw = [
            "写小说", "章节", "剧情", "悬疑", "novel",
            "chapter", "故事", "短篇", "长篇小说",
        ]
        if any(kw in prompt_lower for kw in novel_kw):
            return "novel"

        code_kw = [
            "bug", "修复", "重构", "代码", "code",
            "git", "函数", "class", "debug", "optimize",
        ]
        if any(kw in prompt_lower for kw in code_kw):
            return "code"

        return "chat"

    def _needs_image(self, prompt: str) -> bool:
        """
        判断用户 prompt 是否隐含图像生成需求。

        用于 task_type 不是 'multimodal' 但 prompt 中出现图像相关词的情况。
        """
        image_kw = [
            "图", "画", "image", "picture", "concept art",
            "插图", "插画", "配图", "photo", "drawing",
        ]
        return any(kw in prompt.lower() for kw in image_kw)

    # ------------------------------------------------------------------
    # Reporter 安全包装（吞掉所有异常，保证非阻塞）
    # ------------------------------------------------------------------

    async def _safe_report_stage(
        self,
        task_id: str,
        stage: str,
        message: str,
        progress: Optional[float] = None,
    ) -> None:
        """安全上报阶段状态，任何异常不抛出不阻断主流程。"""
        try:
            await self.reporter.report_stage(task_id, stage, message, progress)
        except Exception as exc:
            logger.debug(f"report_stage  swallowed: {exc}")

    async def _safe_report_result(
        self, task_id: str, status: str, output: str
    ) -> None:
        """安全上报最终结果。"""
        try:
            await self.reporter.report_result(task_id, status, output)
        except Exception as exc:
            logger.debug(f"report_result swallowed: {exc}")

    async def _safe_report_model_info(
        self,
        task_id: str,
        vendor: str,
        model: str,
        prompt_tokens: int,
        completion_tokens: int,
    ) -> None:
        """安全上报模型信息。"""
        try:
            await self.reporter.report_model_info(
                task_id, vendor, model, prompt_tokens, completion_tokens
            )
        except Exception as exc:
            logger.debug(f"report_model_info swallowed: {exc}")

    async def _safe_report_vram(
        self,
        task_id: str,
        state: str,
        embedding_mb: int,
        llm_mb: int,
        comfyui_mb: int,
        free_mb: int,
    ) -> None:
        """安全上报 VRAM 状态。"""
        try:
            await self.reporter.report_vram(
                task_id, state, embedding_mb, llm_mb, comfyui_mb, free_mb
            )
        except Exception as exc:
            logger.debug(f"report_vram swallowed: {exc}")

    # ------------------------------------------------------------------
    # 路由与执行兼容层（兼容同步/异步 router 方法）
    # ------------------------------------------------------------------

    async def _route_decision(self, prompt: str, strategy: Any) -> Any:
        """兼容调用 router.route：无论同步还是异步都能正确处理。"""
        result = self.router.route(prompt, strategy)
        if asyncio.iscoroutine(result):
            return await result
        return result

    async def _execute_decision(self, prompt: str, decision: Any) -> Any:
        """兼容调用 router.execute：适配不同参数顺序。"""
        # 优先检测真实 ModelRouter 的 execute(decision, prompt) 签名
        if hasattr(self.router, "execute_with_role"):
            # 真实 ModelRouter 使用 (decision, prompt) 顺序
            result = self.router.execute(decision, prompt)
        else:
            # stub 使用 (task, decision) 顺序
            result = self.router.execute(prompt, decision)
        if asyncio.iscoroutine(result):
            return await result
        return result

async def _test_single_task() -> None:
    """测试单任务处理：赛博朋克女主角 + 概念图。"""
    orch = HermesOrchestrator()
    result = await orch.process_task({
        "taskId": "test-001",
        "raw_input": "帮我设计一个赛博朋克女主角并生成概念图",
        "strategy": "CREATIVE",
    })
    print("\n=== 单任务结果 ===")
    print(result)


async def _test_novel_task() -> None:
    """测试小说生成 + 评估流水线。"""
    orch = HermesOrchestrator()
    result = await orch.process_task({
        "taskId": "test-novel-001",
        "raw_input": "帮我写一章节悬疑小说，主角是个失忆的侦探",
        "strategy": "CREATIVE",
    })
    print("\n=== 小说任务结果 ===")
    print(result)


async def _test_batch_tasks() -> None:
    """测试批量任务流式处理。"""
    orch = HermesOrchestrator()
    tasks = [
        {"taskId": "batch-001", "raw_input": "写一段Python快速排序代码", "strategy": "BALANCED"},
        {"taskId": "batch-002", "raw_input": "生成一张概念图：未来城市", "strategy": "CREATIVE"},
        {"taskId": "batch-003", "raw_input": "写一章节科幻小说", "strategy": "CREATIVE"},
    ]
    print("\n=== 批量任务流式结果 ===")
    async for res in orch.process_tasks_stream(tasks, max_concurrency=2):
        print(f"  -> {res['taskId']}: status={res['status']}")


async def test() -> None:
    """综合测试入口。"""
    print("=" * 60)
    print("HermesOrchestrator 综合测试")
    print("=" * 60)

    await _test_single_task()
    await _test_novel_task()
    await _test_batch_tasks()

    print("\n" + "=" * 60)
    print("所有测试完成")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(test())
