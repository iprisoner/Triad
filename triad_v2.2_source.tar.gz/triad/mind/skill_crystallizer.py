"""
skill_crystallizer.py — 蜂群技能固化器

当 Swarm 任务获得高分(>=9.0)时，将成功经验固化为可复用的 Markdown+YAML 模板。
存储位置: ~/.triad/memory/skills/self-evolved/
"""

from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import List, Optional, Dict, Any, Tuple
import json
import yaml
import datetime
import re
import logging

# ---------------------------------------------------------------------------
# 日志配置
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# 数据类定义（来自 swarm_orchestrator.py / novel_curator.py 的接口上下文）
# ---------------------------------------------------------------------------

@dataclass
class SwarmRecipe:
    """蜂群任务配方，描述一次 Swarm 执行的完整配置。"""
    user_request_pattern: str
    agent_configs: List[dict]
    aggregation_prompt: Optional[str] = None
    success_score: float = 0.0


@dataclass
class AssessmentReport:
    """小说评估报告，包含各维度评分与综合评语。"""
    overall: float = 0.0                     # 0-10 总分
    character_consistency: float = 0.0
    plot_logic: float = 0.0
    pacing: float = 0.0
    foreshadowing: float = 0.0
    critique: str = ""


# ---------------------------------------------------------------------------
# 核心类: SwarmSkillCrystallizer
# ---------------------------------------------------------------------------

class SwarmSkillCrystallizer:
    """
    蜂群技能结晶器。

    职责：
    1. 监听 AssessmentReport，overall >= 9.0 时触发固化。
    2. 从 SwarmRecipe 提取关键信息，生成 Markdown + YAML 模板。
    3. 自动版本递增，保存到 ~/.triad/memory/skills/self-evolved/。
    4. 支持按关键词检索已固化技能，用于后续任务推荐。
    """

    def __init__(self, skills_dir: str = "~/.triad/memory/skills/self-evolved"):
        """
        初始化技能结晶器。

        :param skills_dir: 技能固化文件存储目录，默认 ~/.triad/memory/skills/self-evolved
        """
        self.skills_dir: Path = Path(skills_dir).expanduser()
        self.skills_dir.mkdir(parents=True, exist_ok=True)
        logger.info("技能结晶器初始化完成，存储目录: %s", self.skills_dir)

    # -----------------------------------------------------------------------
    # 1. 触发判断
    # -----------------------------------------------------------------------

    def should_crystallize(self, report: AssessmentReport) -> bool:
        """
        判断是否应触发固化。

        当 AssessmentReport.overall >= 9.0 时认为值得固化。

        :param report: 评估报告
        :return: True 表示触发固化，False 表示不触发
        """
        return report.overall >= 9.0

    # -----------------------------------------------------------------------
    # 2. 信息提取
    # -----------------------------------------------------------------------

    def extract_swarm_recipe(
        self,
        recipe: SwarmRecipe,
        report: AssessmentReport,
    ) -> Dict[str, Any]:
        """
        从 SwarmRecipe 提取关键信息，构建固化模板所需的数据结构。

        提取字段：
        1. user_request_pattern → trigger_keywords / user_pattern
        2. agent_configs → 每个 Agent 的 system_prompt / model_pref / tools / temperature
        3. aggregation_prompt → 汇总策略
        4. report.overall → success_score
        5. report.critique → improvement_notes

        :param recipe: 本次蜂群任务的配方
        :param report: 本次任务的质量评估报告
        :return: 模板字典，可直接用于生成 Markdown 文件
        """
        # 从 user_request_pattern 提取触发关键词
        trigger_keywords = self._extract_trigger_keywords(recipe.user_request_pattern)

        # 规范化每个 agent 的配置
        agents: List[Dict[str, Any]] = []
        for idx, cfg in enumerate(recipe.agent_configs, start=1):
            agent_entry = {
                "index": idx,
                "role": cfg.get("role", "unknown"),
                "model_preference": cfg.get("model_preference", "GENERAL"),
                "system_prompt": cfg.get("system_prompt", ""),
                "tools": cfg.get("tools", []),
                "temperature": cfg.get("temperature", 0.7),
            }
            agents.append(agent_entry)

        template: Dict[str, Any] = {
            # YAML frontmatter 字段
            "skill_id": "",                     # 后续由 save_skill 填充
            "name": recipe.user_request_pattern[:30] + "蜂群",
            "type": "swarm",
            "source": "self-evolved",
            "version": 1,                       # 后续由 save_skill 更新
            "evidence_count": 1,
            "success_score": float(report.overall),
            "created_at": datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z"),
            "user_pattern": recipe.user_request_pattern,

            # Markdown 正文字段
            "trigger_keywords": trigger_keywords,
            "agents": agents,
            "aggregation_prompt": recipe.aggregation_prompt or "",
            "improvement_notes": report.critique or "",
            "history": [
                {
                    "date": datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z"),
                    "score": float(report.overall),
                    "scenario": recipe.user_request_pattern,
                }
            ],
            "quality_checklist": self._generate_quality_checklist(agents),
        }

        logger.info(
            "提取完成: %d 个 agent, trigger=%s, score=%.1f",
            len(agents), trigger_keywords, report.overall,
        )
        return template

    # -----------------------------------------------------------------------
    # 3. 保存技能
    # -----------------------------------------------------------------------

    def save_skill(self, recipe_name: str, template: Dict[str, Any]) -> str:
        """
        将模板数据保存为 Markdown + YAML frontmatter 文件。

        步骤：
        1. 检查 skills_dir 下是否已有同名技能，自动递增版本号
        2. 生成 YAML frontmatter + Markdown 正文
        3. 写入文件
        4. 返回文件绝对路径

        :param recipe_name: 配方名称（用于构建文件名，如 swarm_cyberpunk_research）
        :param template: extract_swarm_recipe 生成的模板字典
        :return: 保存后的文件绝对路径
        """
        # 计算下一个版本号
        version = self._get_next_version(recipe_name)
        template["version"] = version

        # 生成 skill_id
        skill_id = f"{recipe_name}_v{version}"
        template["skill_id"] = skill_id

        # 文件名: {recipe_name}_v{N}.md
        filename = f"{recipe_name}_v{version}.md"
        file_path = self.skills_dir / filename

        # 构建文件内容
        content = self._build_markdown_file(template)

        # 写入文件
        file_path.write_text(content, encoding="utf-8")
        logger.info("技能已固化: %s", file_path)
        return str(file_path)

    # -----------------------------------------------------------------------
    # 4. 加载所有技能
    # -----------------------------------------------------------------------

    def load_all_skills(self) -> List[Dict[str, Any]]:
        """
        加载所有已固化的 swarm 技能。

        遍历 skills_dir 下所有 .md 文件，解析 YAML frontmatter + Markdown 正文。

        :return: 技能字典列表，每个字典包含完整的 frontmatter 和正文字段
        """
        skills: List[Dict[str, Any]] = []
        if not self.skills_dir.exists():
            return skills

        for md_file in sorted(self.skills_dir.glob("*.md")):
            try:
                skill_data = self._parse_skill_file(md_file)
                if skill_data:
                    skills.append(skill_data)
            except Exception as e:
                logger.warning("解析技能文件失败 %s: %s", md_file.name, e)

        logger.info("加载了 %d 个已固化技能", len(skills))
        return skills

    # -----------------------------------------------------------------------
    # 5. 技能匹配
    # -----------------------------------------------------------------------

    def find_matching_skill(self, user_request: str) -> Optional[Dict[str, Any]]:
        """
        根据用户请求关键词，匹配已固化的技能模板。

        匹配逻辑：
        1. 提取用户请求中的关键词（长度 >= 2 的词）
        2. 与每个技能的 trigger_keywords / user_pattern 进行包含匹配
        3. 返回匹配度最高（success_score 最高）的技能

        用于：下次类似请求时，直接推荐 "上次成功的蜂群配方"。

        :param user_request: 用户原始请求文本
        :return: 最匹配的技能字典，若无匹配返回 None
        """
        all_skills = self.load_all_skills()
        if not all_skills:
            return None

        # 提取用户请求关键词
        request_keywords = self._extract_trigger_keywords(user_request)
        if not request_keywords:
            return None

        best_match: Optional[Dict[str, Any]] = None
        best_score: float = -1.0

        for skill in all_skills:
            # 计算匹配度
            match_score = self._calculate_match_score(
                request_keywords,
                skill.get("trigger_keywords", []),
                skill.get("user_pattern", ""),
            )

            # 加权：匹配度 + 历史成功率
            weighted_score = match_score * 10 + skill.get("success_score", 0)

            if weighted_score > best_score:
                best_score = weighted_score
                best_match = skill

        if best_match:
            logger.info(
                "匹配到技能 %s (加权得分 %.2f)",
                best_match.get("skill_id", "?"),
                best_score,
            )
        return best_match

    # -----------------------------------------------------------------------
    # 6. 版本递增（内部方法）
    # -----------------------------------------------------------------------

    def _get_next_version(self, recipe_name: str) -> int:
        """
        检查 skills_dir 下已有文件，返回下一个可用版本号。

        例如：
        - swarm_cyberpunk_research_v1.md → 返回 2
        - swarm_cyberpunk_research_v2.md → 返回 3
        - 无文件 → 返回 1

        :param recipe_name: 配方名称前缀
        :return: 下一个版本号（整数）
        """
        if not self.skills_dir.exists():
            return 1

        pattern = re.compile(re.escape(recipe_name) + r"_v(\d+)\.md$")
        max_version = 0

        for file_path in self.skills_dir.iterdir():
            if file_path.is_file():
                match = pattern.match(file_path.name)
                if match:
                    version = int(match.group(1))
                    if version > max_version:
                        max_version = version

        return max_version + 1

    # -----------------------------------------------------------------------
    # 7. 辅助方法群
    # -----------------------------------------------------------------------

    @staticmethod
    def _extract_trigger_keywords(user_request_pattern: str) -> List[str]:
        """
        从用户请求模式中提取触发关键词。

        规则：
        - 按常见分隔符（+、空格、逗号）切分
        - 过滤长度 < 2 的词
        - 去重、去空白

        :param user_request_pattern: 用户请求模式文本
        :return: 触发关键词列表
        """
        # 支持 +、空格、逗号、顿号、分号分隔
        raw_tokens = re.split(r"[\s+，、；;]", user_request_pattern)
        keywords = [
            token.strip()
            for token in raw_tokens
            if len(token.strip()) >= 2
        ]
        # 去重（保持顺序）
        seen = set()
        unique_keywords: List[str] = []
        for kw in keywords:
            lower_kw = kw.lower()
            if lower_kw not in seen:
                seen.add(lower_kw)
                unique_keywords.append(kw)
        return unique_keywords

    @staticmethod
    def _generate_quality_checklist(agents: List[Dict[str, Any]]) -> List[str]:
        """
        根据 Agent 配置自动生成质量检查清单。

        :param agents: Agent 配置列表
        :return: 检查项字符串列表
        """
        checklist: List[str] = []
        role_counts: Dict[str, int] = {}
        for agent in agents:
            role = agent.get("role", "")
            role_counts[role] = role_counts.get(role, 0) + 1

            # 根据角色类型生成检查项
            if "research" in role.lower():
                checklist.append("世界观/调研内容完整且有引用依据")
            elif "character" in role.lower() or "design" in role.lower():
                checklist.append("每个角色有明确的核心冲突与动机")
            elif "art" in role.lower() or "direct" in role.lower():
                checklist.append("美术 Prompt 包含材质与风格描述")
            elif "plot" in role.lower() or "story" in role.lower():
                checklist.append("剧情逻辑连贯，伏笔有回收")

        if not checklist:
            checklist.append("输出内容完整，格式符合要求")

        # 去重
        seen = set()
        unique_checklist: List[str] = []
        for item in checklist:
            if item not in seen:
                seen.add(item)
                unique_checklist.append(item)

        return unique_checklist

    def _build_markdown_file(self, template: Dict[str, Any]) -> str:
        """
        构建完整的 Markdown + YAML frontmatter 文件内容。

        :param template: 模板字典
        :return: 完整的文件内容字符串
        """
        # YAML frontmatter 字段
        frontmatter_fields = [
            "skill_id",
            "name",
            "type",
            "source",
            "version",
            "evidence_count",
            "success_score",
            "created_at",
            "user_pattern",
        ]
        frontmatter: Dict[str, Any] = {
            key: template[key] for key in frontmatter_fields if key in template
        }

        # 生成 YAML frontmatter（默认流风格对字符串友好）
        yaml_content = yaml.dump(
            frontmatter,
            allow_unicode=True,
            sort_keys=False,
            default_flow_style=False,
        )

        # Markdown 正文
        body = self._build_markdown_body(template)

        # 拼接
        return f"---\n{yaml_content}---\n{body}\n"

    def _build_markdown_body(self, template: Dict[str, Any]) -> str:
        """
        构建 Markdown 正文部分（不含 frontmatter）。

        :param template: 模板字典
        :return: Markdown 正文字符串
        """
        name = template.get("name", "未命名蜂群")
        trigger_keywords = template.get("trigger_keywords", [])
        agents = template.get("agents", [])
        aggregation = template.get("aggregation_prompt", "")
        checklist = template.get("quality_checklist", [])
        history = template.get("history", [])
        improvement_notes = template.get("improvement_notes", "")

        lines: List[str] = []

        # 标题
        lines.append(f"# {name} — 员工手册")
        lines.append("")

        # 触发条件
        lines.append("## 触发条件")
        lines.append("用户请求包含以下关键词：")
        for kw in trigger_keywords:
            lines.append(f'- "{kw}"')
        lines.append("")

        # 蜂群编队
        lines.append("## 蜂群编队（执行顺序）")
        lines.append("")
        for agent in agents:
            idx = agent.get("index", 0)
            role = agent.get("role", "unknown")
            model_pref = agent.get("model_preference", "GENERAL")
            system_prompt = agent.get("system_prompt", "")
            tools = agent.get("tools", [])
            temperature = agent.get("temperature", 0.7)

            lines.append(f"### Agent {idx}: {role}")
            lines.append(f"- **角色**: {role}")
            lines.append(f"- **模型偏好**: {model_pref}")
            lines.append("- **System Prompt**:")
            lines.append(f"  > {system_prompt}")
            if tools:
                lines.append(f'- **允许工具**: {json.dumps(tools, ensure_ascii=False)}')
            lines.append(f"- **温度**: {temperature}")
            lines.append("")

        # 汇总策略
        lines.append("## 汇总策略")
        if aggregation:
            lines.append("```")
            lines.append("汇总 Prompt:")
            lines.append(aggregation)
            lines.append("```")
        else:
            lines.append("（未配置汇总 Prompt）")
        lines.append("")

        # 质量检查清单
        lines.append("## 质量检查清单")
        for item in checklist:
            lines.append(f"- [ ] {item}")
        lines.append("")

        # 改进建议
        if improvement_notes:
            lines.append("## 改进建议")
            lines.append(improvement_notes)
            lines.append("")

        # 历史战绩
        lines.append("## 历史战绩")
        for record in history:
            date = record.get("date", "未知")
            score = record.get("score", 0.0)
            scenario = record.get("scenario", "")
            lines.append(f"- 第 1 次使用: {date}, 评分 {score}/10")
            if scenario:
                lines.append(f"  - 适用场景: {scenario}")
        lines.append("")

        return "\n".join(lines)

    def _parse_skill_file(self, file_path: Path) -> Optional[Dict[str, Any]]:
        """
        解析单个技能 Markdown 文件，提取 YAML frontmatter 和 Markdown 正文。

        :param file_path: Markdown 文件路径
        :return: 解析后的技能字典，失败返回 None
        """
        content = file_path.read_text(encoding="utf-8")

        # 提取 YAML frontmatter
        frontmatter_match = re.search(r"^---\n(.*?)\n---\n", content, re.DOTALL)
        if not frontmatter_match:
            logger.warning("文件 %s 缺少 YAML frontmatter", file_path.name)
            return None

        try:
            frontmatter = yaml.safe_load(frontmatter_match.group(1))
        except yaml.YAMLError as e:
            logger.warning("解析 YAML 失败 %s: %s", file_path.name, e)
            return None

        if not isinstance(frontmatter, dict):
            return None

        # 正文部分（frontmatter 之后）
        body = content[frontmatter_match.end():]

        # 合并返回
        result = dict(frontmatter)
        result["_body"] = body
        result["_file_path"] = str(file_path)

        # 尝试从正文中提取 trigger_keywords（兜底）
        if "trigger_keywords" not in result:
            trigger_match = re.search(
                r"## 触发条件.*?\n(.*?)(?=\n## |$)",
                body,
                re.DOTALL,
            )
            if trigger_match:
                keywords = re.findall(r'- "(.+?)"', trigger_match.group(1))
                result["trigger_keywords"] = keywords

        return result

    @staticmethod
    def _calculate_match_score(
        request_keywords: List[str],
        skill_keywords: List[str],
        user_pattern: str,
    ) -> float:
        """
        计算用户请求与技能模板的匹配分数。

        :param request_keywords: 用户请求关键词
        :param skill_keywords: 技能触发关键词
        :param user_pattern: 技能用户模式文本
        :return: 匹配分数 (0.0 - 1.0+)
        """
        if not request_keywords:
            return 0.0

        matched = 0
        for kw in request_keywords:
            kw_lower = kw.lower()
            # 直接匹配 skill_keywords
            if any(kw_lower == sk.lower() for sk in skill_keywords):
                matched += 1
                continue
            # 模糊匹配 user_pattern
            if kw_lower in user_pattern.lower():
                matched += 0.5

        # 归一化：完全匹配数 / 请求关键词数（上限 1.0）
        score = matched / len(request_keywords)
        return min(score, 2.0)  # 允许超过 1.0 作为激励


# ---------------------------------------------------------------------------
# 测试入口
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # 测试数据：模拟一次高分的赛博朋克研究蜂群任务
    recipe = SwarmRecipe(
        user_request_pattern="赛博朋克 + 角色设计 + 世界观",
        agent_configs=[
            {
                "role": "世界观研究员",
                "model_preference": "REASONING",
                "system_prompt": (
                    "你是一位科幻社会学研究员。请基于用户提供的主题，构建一个"
                    "详尽的赛博朋克世界观框架，包含：社会结构、技术水平、阶级矛盾、地理环境。"
                ),
                "tools": ["read", "search", "write"],
                "temperature": 0.3,
            },
            {
                "role": "角色设计师",
                "model_preference": "CREATIVE",
                "system_prompt": (
                    "你是一位角色概念设计师。基于研究员提供的世界观，设计 3 个核心角色，"
                    "每个角色包含：姓名、年龄、职业、外貌特征、核心冲突、动机。"
                ),
                "tools": ["read", "write"],
                "temperature": 0.8,
            },
            {
                "role": "美术导演",
                "model_preference": "CREATIVE",
                "system_prompt": (
                    "你是一位视觉艺术导演。基于角色设计师提供的角色描述，为每个角色撰写"
                    "ComfyUI 可用的正向/负向 Prompt，确保风格统一、面部一致性。"
                ),
                "tools": ["generate_image", "asset_search"],
                "temperature": 0.9,
            },
        ],
        aggregation_prompt=(
            "将以上三位专家的研究成果整合为一份完整的创作文档。\n"
            "结构：世界观概述 → 角色档案 → 视觉风格指南 → 推荐工具与模型"
        ),
        success_score=9.2,
    )

    report_high = AssessmentReport(
        overall=9.2,
        character_consistency=9.0,
        plot_logic=8.8,
        pacing=9.5,
        foreshadowing=9.1,
        critique="可适当增强社会阶层描写的深度，增加企业势力间的暗线冲突。",
    )

    report_low = AssessmentReport(
        overall=7.5,
        character_consistency=7.0,
        plot_logic=7.2,
        pacing=8.0,
        foreshadowing=6.5,
        critique="整体节奏尚可，但角色动机不够清晰，需要加强。",
    )

    # 使用临时目录进行测试，避免污染真实目录
    test_dir = Path("/tmp/triad_test_skills")
    crystallizer = SwarmSkillCrystallizer(str(test_dir))

    print("=" * 60)
    print("测试 1: should_crystallize")
    print("=" * 60)
    print(f"高分报告(9.2) → {crystallizer.should_crystallize(report_high)}")  # True
    print(f"低分报告(7.5) → {crystallizer.should_crystallize(report_low)}")   # False

    print("\n" + "=" * 60)
    print("测试 2: extract_swarm_recipe + save_skill")
    print("=" * 60)
    template = crystallizer.extract_swarm_recipe(recipe, report_high)
    saved_path = crystallizer.save_skill("swarm_cyberpunk_research", template)
    print(f"保存路径: {saved_path}")

    # 再次保存同名技能，测试版本递增
    template2 = crystallizer.extract_swarm_recipe(recipe, report_high)
    saved_path2 = crystallizer.save_skill("swarm_cyberpunk_research", template2)
    print(f"版本递增后路径: {saved_path2}")

    print("\n" + "=" * 60)
    print("测试 3: load_all_skills")
    print("=" * 60)
    all_skills = crystallizer.load_all_skills()
    print(f"加载技能数: {len(all_skills)}")
    for skill in all_skills:
        print(f"  - {skill.get('skill_id')} (score={skill.get('success_score')})")

    print("\n" + "=" * 60)
    print("测试 4: find_matching_skill")
    print("=" * 60)
    # 模拟用户新请求
    match = crystallizer.find_matching_skill("我需要设计赛博朋克世界观和角色")
    if match:
        print(f"匹配到技能: {match['skill_id']}")
        print(f"  user_pattern: {match.get('user_pattern')}")
    else:
        print("未匹配到技能")

    # 无匹配请求
    no_match = crystallizer.find_matching_skill("给我写一份财务报告")
    print(f"无关请求匹配结果: {no_match}")

    print("\n" + "=" * 60)
    print("测试 5: 查看生成的文件内容")
    print("=" * 60)
    first_file = test_dir / "swarm_cyberpunk_research_v1.md"
    if first_file.exists():
        print(first_file.read_text(encoding="utf-8"))

    # 清理测试目录
    import shutil
    shutil.rmtree(test_dir, ignore_errors=True)
    print("\n测试完成，临时目录已清理。")
